from model.avaliador import Avaliador
from model.carregador import Carregador
from model.modelo import Model

# To run: pytest -v test_modelos.py
    
# Método para testar o modelo a partir do arquivo correspondente
# O nome do método a ser testado necessita começar com "test_"
def test_modelo():
    # Instanciação das Classes
    carregador = Carregador()
    modelo = Model()
    avaliador = Avaliador()

    # Parâmetros    
    url_dados = "https://raw.githubusercontent.com/eltontourinhorj/Heart-Attack-Analysis-Prediction-Dataset/main/heart.csv"
    colunas = ['age', 'sex', 'cp', 'trtbps', 'chol', 'fbs', 'restecg', 'thalachh','exng','oldpeak','slp','caa','thall', 'output']

    # Carga dos dados
    dataset = carregador.carregar_dados(url_dados, colunas).values

    # Separando em dados de entrada e saída
    X = dataset[:, 0:-1]
    Y = dataset[:, -1] 
    # Importando o modelo de regressão logística
    path = 'ml_model/model.pkl'
    modelo = modelo.carrega_modelo(path)

    # Obtendo as métricas da Regressão Logística
    acuracia, recall, precisao, f1 = avaliador.avaliar(modelo, X, Y)
    
    # Testando as métricas da Regressão Logística 
    # Modifique as métricas de acordo com seus requisitos
    assert acuracia >= 0.77
    assert precisao >= 0.80
    assert recall >= 0.7
    assert f1 >= 0.78
