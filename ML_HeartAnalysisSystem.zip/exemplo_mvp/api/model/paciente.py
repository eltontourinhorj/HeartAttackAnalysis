from sqlalchemy import Column, String, Integer, DateTime, Float
from sqlalchemy.orm import relationship
from datetime import datetime
from typing import Union

from  model import Base

class Paciente(Base):
    __tablename__ = 'pacientes'
    
    id = Column(Integer, primary_key=True)
    name= Column("Name", String(50))
    age= Column("age", Integer)
    sex = Column("sex", Integer)
    exng = Column("exng", Integer)
    cp = Column("cp", Integer)
    trtbps = Column("trtbps", Integer)
    chol = Column("chol", Integer)
    fbs = Column("fbs", Integer)
    restecg = Column("restecg", Integer)
    thalachh = Column("thalachh", Integer)
    oldpeak = Column("oldpeak", Float)
    slp = Column("slp", Integer)
    caa = Column("caa", Integer)
    thall = Column("thall", Integer)
    output = Column("output", Integer, nullable=True)
    data_insercao = Column(DateTime, default=datetime.now())
    
    def __init__(self, name:str, age:int, sex:int, exng:int,
                 cp:int, trtbps:int, chol:int, 
                 fbs:int, restecg:int, thalachh:int,
                 oldpeak:float, slp:int, caa:int,
                 thall:int, output:int,
                 data_insercao:Union[DateTime, None] = None):
        """
        Cria um Paciente

        Arguments:
            name: Nome do paciente
            age : Idade do paciente
            sex : Sexo do paciente
            exang: Angina induzida por exercício (1 = sim; 0 = não)
            caa: Número de grandes vasos sanguíneos (0-3)
            cp : Tipo de dor no peito

            Valor 1: angina típica
            Valor 2: angina atípica
            Valor 3: dor não anginosa
            Valor 4: assintomático

            trtbps : Pressão arterial em repouso (em mm Hg)
            chol : Colesterol em mg/dl obtido via sensor de IMC
            fbs : (glicose no sangue em jejum > 120 mg/dl) (1 = verdadeiro; 0 = falso)
            rest_ecg : Resultados eletrocardiográficos em repouso

            Valor 0: normal
            Valor 1: apresentando anormalidade de onda ST-T (inversões de onda T e/ou elevação ou depressão de > 0.05 mV)
            Valor 2: mostrando hipertrofia ventricular esquerda provável ou definitiva pelos critérios de Estes

            thalachh : Frequência cardíaca máxima atingida
            target : 0= menor chance de ataque cardíaco 1= maior chance de ataque cardíaco
        """

        self.name = name
        self.age = age
        self.sex = sex
        self.exng = exng
        self.cp = cp
        self.trtbps = trtbps
        self.chol = chol
        self.fbs = fbs
        self.restecg = restecg
        self.thalachh = thalachh
        self.oldpeak = oldpeak
        self.slp = slp
        self.caa = caa
        self.thall = thall
        self.output = output

        # se não for informada, será o data exata da inserção no banco
        if data_insercao:
            self.data_insercao = data_insercao