# Meu Front

Este pequeno projeto faz parte do material didático da Disciplina **Desenvolvimento Full Stack Básico** 

O objetivo aqui é ilutsrar o conteúdo apresentado na terceira aula.

---
## Como executar

Basta fazer o download do projeto e abrir o arquivo index.html no seu browser.
